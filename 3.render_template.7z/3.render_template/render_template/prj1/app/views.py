#app/views.py
from django.shortcuts import render
from django.shortcuts import HttpResponse

productList = [
    {'code': 'IPX', 'name': 'IPhone X', 'price': 12.5},
    {'code': 'IP8', 'name': 'IPhone 8', 'price': 8.5},
    {'code': 'S3', 'name': 'Galaxy S3', 'price': 6.5},
    {'code': 'S4', 'name': 'Galaxy S4', 'price': 10.5},
]

def index(request):
    context = {'productList': productList}
    return render(request, 'index.html', context)



#app/views.py
from django.shortcuts import render
from django.shortcuts import HttpResponse
from .models import Product

def index(request):
    productName = request.GET.get('productName', '')
    productList = Product.objects.filter(name__contains=productName)
    context = {
        'productList': productList,
        'productName': productName,
    }
    return render(request, 'index.html', context)



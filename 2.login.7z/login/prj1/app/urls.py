#app/urls.py
from django.urls import path
from django.urls import include
from .views import *
from .views_staff import *

urlpatterns = [
    path('', index, name='home'),
    path('accounts/', include('django.contrib.auth.urls')),

    path('staff', staffHome, name='staff-home'),
]
#app/views.py
from django.shortcuts import render
from django.shortcuts import HttpResponse

def index(request):
    return render(request, 'index.html')

#GET method
def hello(request):#127.0.0.1:8000/hello?username=user1
    username = request.GET.get('username', '')
    return HttpResponse('Hello ' + username)

#POST method
def hello2(request): # 127.0.0.1:8000/hello2
    if request.method == 'GET':
        return render(request, 'hello2.html')
    else:
        username = request.POST.get('username', '')
        return HttpResponse('Hello ' + username)

#app/urls.py
from django.urls import path
from .views import *

urlpatterns = [
    path('', index, name='home'),  
    path('create_product', ProductCreateView.as_view(), name='product-create'),  
    path('update_product/<pk>', ProductUpdateView.as_view(), name='product-update'),
]
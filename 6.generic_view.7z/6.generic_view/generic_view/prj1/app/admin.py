from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Product)
#127.0.0.1:8000/admin

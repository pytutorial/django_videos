#app/views_staff.py

from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def staffHome(request):
    return render(request, 'staff/index.html')